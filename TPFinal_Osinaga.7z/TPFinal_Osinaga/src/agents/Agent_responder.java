package agents;


import jade.content.ContentElement; 
import jade.content.lang.Codec.CodecException;

import jade.content.onto.OntologyException;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;
import jade.wrapper.*;
import Ontology.IsMyZeuthen;
import fsm.EsperarPropuestaInicialBehaviour;


public class Agent_responder extends AgentNegotiator {
		

	protected void setup() {
		
		super.setup();
		// Crea una descripci�n del agente para el DF
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName(getAID());
		
		// Crea una descripci�n del servicio
		ServiceDescription sd = new ServiceDescription();
		sd.setType("Pelicula");
		sd.setName("recibe-propuesta");
		dfd.addServices(sd);
		try {
			DFService.register(this, dfd);
			
		}
		catch (FIPAException fe) {
			fe.printStackTrace();
		}
				
		this.addBehaviour(new EsperarPropuestaInicialBehaviour());
		
		//Create Agent initiator
		createOtherAgent();
			
	}
	
private void createOtherAgent() {
		AgentContainer c = getContainerController();
		try {
	       AgentController control = c.createNewAgent( "Agent_initiator", "agents.Agent_initiator",null); // Program arguments -gui Agent_responder:agents.Agent_responder
	       control.start();
		}
		catch (StaleProxyException e){}
	}


protected void takeDown() {
	try {
		DFService.deregister(this);
	}
	catch (FIPAException fe) {
		fe.printStackTrace();
	}

}
	
}
