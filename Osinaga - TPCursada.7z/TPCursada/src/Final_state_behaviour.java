import jade.core.behaviours.Behaviour;

public class Final_state_behaviour extends Behaviour {

	@Override
	public void action() {
		// TODO Auto-generated method stub
		System.out.println("Final state");
		
	}

	@Override
	public boolean done() {
		// TODO Auto-generated method stub
		return true;
	}

}
